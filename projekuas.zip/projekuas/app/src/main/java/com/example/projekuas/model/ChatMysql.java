package com.example.projekuas.model;

public class ChatMysql {

    public String id;
    public String barangId;
    public String namaBarang;
    public String fotoBarang;
    public String pengirim;
    public String penerima;
    public String pesan;
    public String waktu;

    public ChatMysql() {
    }
}