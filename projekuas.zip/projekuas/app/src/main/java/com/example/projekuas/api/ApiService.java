package com.example.projekuas.api;

import com.example.projekuas.model.Barang;
import com.example.projekuas.model.ChatMysql;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {

    @GET("get_barang.php")
    Call<List<Barang>> getBarang();

    @Multipart
    @POST("upload_barang.php")
    Call<ResponseBody> uploadBarang(
            @Part MultipartBody.Part foto,
            @Part("nama") RequestBody nama,
            @Part("harga") RequestBody harga,
            @Part("kategori") RequestBody kategori,
            @Part("deskripsi") RequestBody deskripsi,
            @Part("penjualNama") RequestBody penjualNama
    );

    @FormUrlEncoded
    @POST("update_barang.php")
    Call<ResponseBody> updateBarang(
            @Field("id") String id,
            @Field("nama") String nama,
            @Field("harga") String harga,
            @Field("kategori") String kategori,
            @Field("deskripsi") String deskripsi
    );

    @FormUrlEncoded
    @POST("delete_barang.php")
    Call<ResponseBody> deleteBarang(
            @Field("id") String id
    );

    @FormUrlEncoded
    @POST("kirim_chat.php")
    Call<ResponseBody> kirimChat(
            @Field("barangId") String barangId,
            @Field("namaBarang") String namaBarang,
            @Field("fotoBarang") String fotoBarang,
            @Field("pengirim") String pengirim,
            @Field("penerima") String penerima,
            @Field("pesan") String pesan
    );

    @FormUrlEncoded
    @POST("delete_chat.php")
    Call<ResponseBody> deleteChat(
            @Field("barangId") String barangId,
            @Field("user") String user
    );

    @GET("get_chat.php")
    Call<List<ChatMysql>> getChat(
            @Query("barangId") String barangId
    );

    @GET("get_list_chat.php")
    Call<List<ChatMysql>> getListChat(
            @Query("user") String user
    );
}