package com.example.projekuas.model;

public class Chat {

    public String id;
    public String pengirimId;
    public String penerimaId;
    public String pesan;
    public String waktu;
    public String barangId;

    public Chat() {
        // wajib untuk Firestore
    }

    public Chat(String id,
                String pengirimId,
                String penerimaId,
                String pesan,
                String waktu,
                String barangId) {

        this.id = id;
        this.pengirimId = pengirimId;
        this.penerimaId = penerimaId;
        this.pesan = pesan;
        this.waktu = waktu;
        this.barangId = barangId;
    }
}