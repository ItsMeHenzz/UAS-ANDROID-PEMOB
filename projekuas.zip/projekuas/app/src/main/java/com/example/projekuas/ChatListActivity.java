package com.example.projekuas;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.ChatListAdapter;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.example.projekuas.model.ChatMysql;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatListActivity extends AppCompatActivity {

    ImageView btnKembali;
    RecyclerView recyclerView;

    ArrayList<ChatMysql> list;
    ChatListAdapter adapter;

    FirebaseAuth auth;
    ApiService api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        auth = FirebaseAuth.getInstance();
        api = RetrofitClient.getRetrofit().create(ApiService.class);

        btnKembali = findViewById(R.id.btnKembali);
        recyclerView = findViewById(R.id.recyclerChatList);

        btnKembali.setOnClickListener(v -> finish());

        list = new ArrayList<>();
        adapter = new ChatListAdapter(this, list);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        aktifkanSwipeHapus();

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    void loadData() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Silakan login dulu", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String email = auth.getCurrentUser().getEmail();

        if (email == null || email.isEmpty()) {
            Toast.makeText(this, "Email user kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        api.getListChat(email).enqueue(new Callback<List<ChatMysql>>() {
            @Override
            public void onResponse(Call<List<ChatMysql>> call,
                                   Response<List<ChatMysql>> response) {

                if (response.isSuccessful() && response.body() != null) {
                    list.clear();
                    list.addAll(response.body());
                    adapter.notifyDataSetChanged();

                } else {
                    Toast.makeText(ChatListActivity.this,
                            "Response kosong / gagal",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<ChatMysql>> call, Throwable t) {
                Toast.makeText(ChatListActivity.this,
                        "Gagal memuat pesan: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    void aktifkanSwipeHapus() {
        ItemTouchHelper.SimpleCallback callback =
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {

                    @Override
                    public boolean onMove(RecyclerView recyclerView,
                                          RecyclerView.ViewHolder viewHolder,
                                          RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                        int position = viewHolder.getAdapterPosition();

                        if (position == RecyclerView.NO_POSITION) {
                            return;
                        }

                        ChatMysql chat = list.get(position);

                        if (auth.getCurrentUser() == null) {
                            adapter.notifyItemChanged(position);
                            return;
                        }

                        String userEmail = auth.getCurrentUser().getEmail();

                        if (userEmail == null || userEmail.isEmpty()) {
                            adapter.notifyItemChanged(position);
                            Toast.makeText(ChatListActivity.this,
                                    "Email user kosong",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (chat.barangId == null || chat.barangId.isEmpty()) {
                            adapter.notifyItemChanged(position);
                            Toast.makeText(ChatListActivity.this,
                                    "Barang ID kosong",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        api.deleteChat(chat.barangId, userEmail)
                                .enqueue(new Callback<ResponseBody>() {
                                    @Override
                                    public void onResponse(Call<ResponseBody> call,
                                                           Response<ResponseBody> response) {

                                        if (response.isSuccessful()) {
                                            list.remove(position);
                                            adapter.notifyItemRemoved(position);

                                            Toast.makeText(ChatListActivity.this,
                                                    "Chat dihapus",
                                                    Toast.LENGTH_SHORT).show();
                                        } else {
                                            adapter.notifyItemChanged(position);

                                            Toast.makeText(ChatListActivity.this,
                                                    "Gagal hapus chat",
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                                        adapter.notifyItemChanged(position);

                                        Toast.makeText(ChatListActivity.this,
                                                "Gagal hapus: " + t.getMessage(),
                                                Toast.LENGTH_LONG).show();
                                    }
                                });
                    }
                };

        new ItemTouchHelper(callback).attachToRecyclerView(recyclerView);
    }
}