package com.example.projekuas;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileActivity extends AppCompatActivity {

    ImageView imgProfile;

    TextView txtNama, txtEmail, btnEditProfil, btnRiwayat;
    TextView menuHome, menuJual, menuChat, menuProfile;

    LinearLayout btnFavorite, btnPesan, btnDilihat, btnUlasan;

    Button btnLogout;

    FirebaseAuth auth;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        imgProfile = findViewById(R.id.imgProfile);

        txtNama = findViewById(R.id.txtNama);
        txtEmail = findViewById(R.id.txtEmail);

        btnEditProfil = findViewById(R.id.btnEditProfil);
        btnFavorite = findViewById(R.id.btnFavorite);
        btnPesan = findViewById(R.id.btnPesan);
        btnDilihat = findViewById(R.id.btnDilihat);
        btnUlasan = findViewById(R.id.btnUlasan);
        btnRiwayat = findViewById(R.id.btnRiwayat);

        btnLogout = findViewById(R.id.btnLogout);

        menuHome = findViewById(R.id.menuHome);
        menuJual = findViewById(R.id.menuJual);
        menuChat = findViewById(R.id.menuChat);
        menuProfile = findViewById(R.id.menuProfile);

        btnEditProfil.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, EditProfilActivity.class))
        );

        btnFavorite.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, FavoriteActivity.class))
        );

        btnPesan.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, ChatListActivity.class))
        );

        btnUlasan.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, DaftarUlasanActivity.class))
        );

        btnDilihat.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, BarangSayaActivity.class))
        );

        if (btnRiwayat != null) {
            btnRiwayat.setOnClickListener(v ->
                    startActivity(new Intent(ProfileActivity.this, RiwayatActivity.class))
            );
        }

        btnLogout.setOnClickListener(v -> {
            auth.signOut();

            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
            finish();
        });

        menuHome.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });

        menuJual.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, UploadBarangActivity.class))
        );

        menuChat.setOnClickListener(v ->
                startActivity(new Intent(ProfileActivity.this, ChatListActivity.class))
        );

        menuProfile.setOnClickListener(v ->
                Toast.makeText(this, "Kamu sedang di halaman Profil", Toast.LENGTH_SHORT).show()
        );

        loadProfile();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProfile();
    }

    void loadProfile() {
        if (auth.getCurrentUser() == null) {
            startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
            finish();
            return;
        }

        String uid = auth.getCurrentUser().getUid();
        String emailLogin = auth.getCurrentUser().getEmail();

        txtEmail.setText(emailLogin);
        txtNama.setText(emailLogin != null ? emailLogin : "Nama User");

        Glide.with(ProfileActivity.this)
                .load(R.drawable.ic_person_pp)
                .circleCrop()
                .into(imgProfile);

        db.collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {

                        String nama = doc.getString("nama");

                        if (nama == null || nama.isEmpty()) nama = doc.getString("displayName");
                        if (nama == null || nama.isEmpty()) nama = doc.getString("name");

                        String email = doc.getString("email");

                        String foto = doc.getString("foto");

                        if (foto == null || foto.isEmpty()) foto = doc.getString("photo");
                        if (foto == null || foto.isEmpty()) foto = doc.getString("photoUrl");
                        if (foto == null || foto.isEmpty()) foto = doc.getString("profileImage");
                        if (foto == null || foto.isEmpty()) foto = doc.getString("profileUrl");

                        if (nama != null && !nama.isEmpty()) {
                            txtNama.setText(nama);
                        } else {
                            txtNama.setText(emailLogin != null ? emailLogin : "Nama User");
                        }

                        if (email != null && !email.isEmpty()) {
                            txtEmail.setText(email);
                        } else {
                            txtEmail.setText(emailLogin);
                        }

                        if (foto != null && !foto.isEmpty()) {
                            try {
                                Glide.with(ProfileActivity.this)
                                        .load(Uri.parse(foto))
                                        .circleCrop()
                                        .placeholder(R.drawable.ic_person_pp)
                                        .error(R.drawable.ic_person_pp)
                                        .into(imgProfile);
                            } catch (Exception e) {
                                Glide.with(ProfileActivity.this)
                                        .load(R.drawable.ic_person_pp)
                                        .circleCrop()
                                        .into(imgProfile);
                            }
                        } else {
                            Glide.with(ProfileActivity.this)
                                    .load(R.drawable.ic_person_pp)
                                    .circleCrop()
                                    .into(imgProfile);
                        }

                    } else {
                        txtNama.setText(emailLogin != null ? emailLogin : "Nama User");
                        txtEmail.setText(emailLogin);

                        Glide.with(ProfileActivity.this)
                                .load(R.drawable.ic_person_pp)
                                .circleCrop()
                                .into(imgProfile);
                    }
                })
                .addOnFailureListener(e -> {
                    txtNama.setText(emailLogin != null ? emailLogin : "Nama User");
                    txtEmail.setText(emailLogin);

                    Glide.with(ProfileActivity.this)
                            .load(R.drawable.ic_person_pp)
                            .circleCrop()
                            .into(imgProfile);
                });
    }
}