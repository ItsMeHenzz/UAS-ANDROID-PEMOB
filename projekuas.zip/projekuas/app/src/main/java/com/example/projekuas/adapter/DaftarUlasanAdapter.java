package com.example.projekuas.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.R;
import com.example.projekuas.model.Ulasan;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class DaftarUlasanAdapter extends RecyclerView.Adapter<DaftarUlasanAdapter.ViewHolder> {

    Context context;
    ArrayList<Ulasan> list;

    public DaftarUlasanAdapter(Context context, ArrayList<Ulasan> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public DaftarUlasanAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_daftar_ulasan, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DaftarUlasanAdapter.ViewHolder holder, int position) {
        Ulasan ulasan = list.get(position);

        holder.txtNamaBarang.setText(ulasan.namaBarang);
        holder.txtPenjual.setText("Penjual • " + ulasan.penjual);
        holder.txtKomentar.setText(ulasan.komentar);
        holder.ratingBar.setRating(ulasan.rating);

        try {
            holder.ratingBar.getProgressDrawable()
                    .setTint(Color.parseColor("#FBBF24"));
        } catch (Exception ignored) {
        }

        holder.btnDelete.setOnClickListener(v -> {
            int pos = holder.getAdapterPosition();

            if (pos == RecyclerView.NO_POSITION) {
                return;
            }

            Ulasan item = list.get(pos);

            if (item.documentId == null || item.documentId.isEmpty()) {
                Toast.makeText(context, "ID ulasan kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseFirestore.getInstance()
                    .collection("ulasan")
                    .document(item.documentId)
                    .delete()
                    .addOnSuccessListener(unused -> {
                        list.remove(pos);
                        notifyItemRemoved(pos);

                        Toast.makeText(context,
                                "Ulasan berhasil dihapus",
                                Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(context,
                                    "Gagal hapus ulasan: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show()
                    );
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtNamaBarang, txtPenjual, txtKomentar;
        RatingBar ratingBar;
        ImageView btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtNamaBarang = itemView.findViewById(R.id.txtNamaBarang);
            txtPenjual = itemView.findViewById(R.id.txtPenjual);
            txtKomentar = itemView.findViewById(R.id.txtKomentar);
            ratingBar = itemView.findViewById(R.id.ratingBar);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}