package com.example.projekuas;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.BarangAdapter;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.example.projekuas.model.Barang;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    EditText edtCari;
    Button btnUpload, btnLogout, menuJual;

    TextView txtWelcome;
    TextView menuHome, menuKategori, menuChat, menuProfile;
    TextView katAksesoris, katFashion, katBuku, katElektronik, katLainnya;

    RecyclerView recyclerBarang;
    ArrayList<Barang> barangList;
    BarangAdapter adapter;

    FirebaseAuth auth;
    FirebaseFirestore db;
    ApiService apiService;

    final int WARNA_AKTIF = Color.parseColor("#1976D2");
    final int WARNA_NONAKTIF = Color.parseColor("#9E9E9E");

    String keywordAktif = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        if (auth.getCurrentUser() == null) {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
            return;
        }

        edtCari = findViewById(R.id.edtCari);
        txtWelcome = findViewById(R.id.txtWelcome);

        btnUpload = findViewById(R.id.btnUpload);
        btnLogout = findViewById(R.id.btnLogout);
        menuJual = findViewById(R.id.menuJual);

        menuHome = findViewById(R.id.menuHome);
        menuKategori = findViewById(R.id.menuKategori);
        menuChat = findViewById(R.id.menuChat);
        menuProfile = findViewById(R.id.menuProfile);

        katAksesoris = findViewById(R.id.katAksesoris);
        katFashion = findViewById(R.id.katFashion);
        katBuku = findViewById(R.id.katBuku);
        katElektronik = findViewById(R.id.katElektronik);
        katLainnya = findViewById(R.id.katLainnya);

        recyclerBarang = findViewById(R.id.recyclerBarang);

        barangList = new ArrayList<>();
        adapter = new BarangAdapter(this, barangList);

        recyclerBarang.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerBarang.setAdapter(adapter);

        setMenuAktif(menuHome);
        loadWelcomeName();

        edtCari.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                keywordAktif = s.toString().trim();
                loadBarang(keywordAktif);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        menuJual.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, UploadBarangActivity.class))
        );

        menuKategori.setOnClickListener(v -> {
            resetMenu();
            startActivity(new Intent(MainActivity.this, UploadBarangActivity.class));
        });

        menuChat.setOnClickListener(v -> {
            resetMenu();
            menuChat.setTextColor(WARNA_AKTIF);
            menuChat.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_AKTIF));
            startActivity(new Intent(MainActivity.this, ChatListActivity.class));
        });

        menuProfile.setOnClickListener(v -> {
            resetMenu();
            menuProfile.setTextColor(WARNA_AKTIF);
            menuProfile.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_AKTIF));
            startActivity(new Intent(MainActivity.this, ProfileActivity.class));
        });

        menuHome.setOnClickListener(v -> {
            setMenuAktif(menuHome);
            keywordAktif = "";
            edtCari.setText("");
            loadBarang("");
        });

        katAksesoris.setOnClickListener(v -> {
            keywordAktif = "aksesoris";
            loadBarang(keywordAktif);
        });

        katFashion.setOnClickListener(v -> {
            keywordAktif = "Fashion";
            loadBarang(keywordAktif);
        });

        katBuku.setOnClickListener(v -> {
            keywordAktif = "Buku";
            loadBarang(keywordAktif);
        });

        katElektronik.setOnClickListener(v -> {
            keywordAktif = "elektronik";
            loadBarang(keywordAktif);
        });

        katLainnya.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, KategoriActivity.class);
            intent.putExtra("kategori", "SEMUA");
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            auth.signOut();

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
            finish();
        });

        edtCari.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || actionId == EditorInfo.IME_ACTION_DONE) {

                keywordAktif = edtCari.getText().toString().trim();
                loadBarang(keywordAktif);
                return true;
            }

            return false;
        });

        loadBarang("");
    }

    @Override
    protected void onResume() {
        super.onResume();
        setMenuAktif(menuHome);
        loadWelcomeName();
        loadBarang(keywordAktif);
    }

    void loadWelcomeName() {
        if (auth.getCurrentUser() == null) return;

        String uid = auth.getCurrentUser().getUid();
        String email = auth.getCurrentUser().getEmail();

        txtWelcome.setText("Welcome, " + (email != null ? email : "Nama User") + " 👋");

        db.collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    String nama = null;

                    if (doc.exists()) {
                        nama = doc.getString("nama");

                        if (nama == null || nama.isEmpty()) {
                            nama = doc.getString("displayName");
                        }

                        if (nama == null || nama.isEmpty()) {
                            nama = doc.getString("name");
                        }
                    }

                    if (nama != null && !nama.isEmpty()) {
                        txtWelcome.setText("Welcome, " + nama + " 👋");
                    } else {
                        txtWelcome.setText("Welcome, " + (email != null ? email : "Nama User") + " 👋");
                    }
                })
                .addOnFailureListener(e ->
                        txtWelcome.setText("Welcome, " + (email != null ? email : "Nama User") + " 👋")
                );
    }

    void resetMenu() {
        menuHome.setTextColor(WARNA_NONAKTIF);
        menuKategori.setTextColor(WARNA_NONAKTIF);
        menuChat.setTextColor(WARNA_NONAKTIF);
        menuProfile.setTextColor(WARNA_NONAKTIF);

        menuHome.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_NONAKTIF));
        menuKategori.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_NONAKTIF));
        menuChat.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_NONAKTIF));
        menuProfile.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_NONAKTIF));
    }

    void setMenuAktif(TextView menuAktif) {
        resetMenu();

        menuAktif.setTextColor(WARNA_AKTIF);
        menuAktif.setCompoundDrawableTintList(ColorStateList.valueOf(WARNA_AKTIF));
    }

    void loadBarang(String keyword) {
        apiService.getBarang().enqueue(new Callback<List<Barang>>() {
            @Override
            public void onResponse(Call<List<Barang>> call,
                                   Response<List<Barang>> response) {

                if (response.isSuccessful() && response.body() != null) {
                    barangList.clear();

                    for (Barang barang : response.body()) {
                        String nama = barang.nama == null ? "" : barang.nama;
                        String kategori = barang.kategori == null ? "" : barang.kategori;
                        String deskripsi = barang.deskripsi == null ? "" : barang.deskripsi;

                        if (keyword.isEmpty()
                                || nama.toLowerCase().contains(keyword.toLowerCase())
                                || kategori.toLowerCase().contains(keyword.toLowerCase())
                                || deskripsi.toLowerCase().contains(keyword.toLowerCase())) {

                            barangList.add(barang);
                        }
                    }

                    adapter.notifyDataSetChanged();

                } else {
                    Toast.makeText(MainActivity.this,
                            "Data barang kosong",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Barang>> call, Throwable t) {
                Toast.makeText(MainActivity.this,
                        "Gagal konek API: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}