package com.example.projekuas.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.projekuas.DetailBarangActivity;
import com.example.projekuas.EditBarangActivity;
import com.example.projekuas.R;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.example.projekuas.model.Barang;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BarangAdapter extends RecyclerView.Adapter<BarangAdapter.ViewHolder> {

    Context context;
    ArrayList<Barang> barangList;
    boolean modeBarangSaya = false;

    public BarangAdapter(Context context, ArrayList<Barang> barangList) {
        this.context = context;
        this.barangList = barangList;
    }

    public BarangAdapter(Context context, ArrayList<Barang> barangList, boolean modeBarangSaya) {
        this.context = context;
        this.barangList = barangList;
        this.modeBarangSaya = modeBarangSaya;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_barang, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Barang barang = barangList.get(position);

        holder.txtNama.setText(barang.nama);
        holder.txtHarga.setText("Rp " + barang.harga);
        holder.txtKategori.setText(barang.kategori);
        holder.txtPenjual.setText(barang.penjualNama);

        Glide.with(context)
                .load(barang.fotoUrl)
                .placeholder(R.drawable.ic_launcher_background)
                .into(holder.imgBarang);

        holder.itemView.setOnClickListener(v -> {
            int currentPosition = holder.getAdapterPosition();

            if (currentPosition == RecyclerView.NO_POSITION) {
                return;
            }

            Barang currentBarang = barangList.get(currentPosition);

            if (modeBarangSaya) {
                tampilMenuBarang(currentBarang, currentPosition);
            } else {
                bukaDetail(currentBarang);
            }
        });
    }

    void bukaDetail(Barang barang) {
        Intent intent = new Intent(context, DetailBarangActivity.class);

        intent.putExtra("id", barang.id);
        intent.putExtra("nama", barang.nama);
        intent.putExtra("harga", barang.harga);
        intent.putExtra("kategori", barang.kategori);
        intent.putExtra("deskripsi", barang.deskripsi);
        intent.putExtra("foto", barang.fotoUrl);
        intent.putExtra("penjual", barang.penjualNama);

        context.startActivity(intent);
    }

    void tampilMenuBarang(Barang barang, int position) {
        String[] pilihan = {"Edit Barang", "Hapus Barang", "Lihat Detail"};

        new AlertDialog.Builder(context)
                .setTitle(barang.nama)
                .setItems(pilihan, (dialog, which) -> {
                    if (which == 0) {
                        Intent intent = new Intent(context, EditBarangActivity.class);
                        intent.putExtra("id", barang.id);
                        intent.putExtra("nama", barang.nama);
                        intent.putExtra("harga", barang.harga);
                        intent.putExtra("kategori", barang.kategori);
                        intent.putExtra("deskripsi", barang.deskripsi);
                        context.startActivity(intent);
                    } else if (which == 1) {
                        konfirmasiHapus(barang);
                    } else {
                        bukaDetail(barang);
                    }
                })
                .show();
    }

    void konfirmasiHapus(Barang barang) {
        new AlertDialog.Builder(context)
                .setTitle("Hapus Barang")
                .setMessage("Yakin mau hapus " + barang.nama + "?")
                .setPositiveButton("Hapus", (dialog, which) -> hapusBarang(barang))
                .setNegativeButton("Batal", null)
                .show();
    }

    void hapusBarang(Barang barang) {
        if (barang.id == null || barang.id.isEmpty()) {
            Toast.makeText(context, "ID barang kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        apiService.deleteBarang(barang.id).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String hasil = response.body().string();

                        if (hasil.contains("\"status\":true")
                                || hasil.contains("success")
                                || hasil.contains("berhasil")) {

                            int posisi = barangList.indexOf(barang);

                            if (posisi != -1) {
                                barangList.remove(posisi);
                                notifyItemRemoved(posisi);
                                notifyItemRangeChanged(posisi, barangList.size());
                            }

                            Toast.makeText(context, "Barang berhasil dihapus", Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(context, "Hapus gagal: " + hasil, Toast.LENGTH_LONG).show();
                        }

                    } catch (IOException e) {
                        Toast.makeText(context, "Gagal baca response: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(context, "Hapus gagal dari server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(context, "Gagal hapus: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return barangList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgBarang;
        TextView txtNama, txtHarga, txtKategori, txtPenjual;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgBarang = itemView.findViewById(R.id.imgBarang);
            txtNama = itemView.findViewById(R.id.txtNama);
            txtHarga = itemView.findViewById(R.id.txtHarga);
            txtKategori = itemView.findViewById(R.id.txtKategori);
            txtPenjual = itemView.findViewById(R.id.txtPenjual);
        }
    }
}