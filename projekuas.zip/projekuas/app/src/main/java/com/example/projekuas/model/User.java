package com.example.projekuas.model;

public class User {

    public String id;
    public String nama;
    public String email;
    public String kampus;
    public String noHp;

    public User() {
        // wajib kosong untuk Firebase
    }

    public User(String id, String nama, String email, String kampus, String noHp) {
        this.id = id;
        this.nama = nama;
        this.email = email;
        this.kampus = kampus;
        this.noHp = noHp;
    }
}