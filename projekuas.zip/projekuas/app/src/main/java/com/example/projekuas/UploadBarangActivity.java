package com.example.projekuas;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.google.firebase.auth.FirebaseAuth;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UploadBarangActivity extends AppCompatActivity {

    EditText edtNama, edtHarga, edtDeskripsi;
    Spinner spinnerKategori;

    TextView btnSimpan, btnPilihFoto;
    ImageView btnKembali, imgPreview;

    Uri imageUri;
    ApiService apiService;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_barang);

        auth = FirebaseAuth.getInstance();
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        btnKembali = findViewById(R.id.btnKembali);

        edtNama = findViewById(R.id.edtNama);
        edtHarga = findViewById(R.id.edtHarga);
        edtDeskripsi = findViewById(R.id.edtDeskripsi);

        spinnerKategori = findViewById(R.id.spinnerKategori);

        btnSimpan = findViewById(R.id.btnSimpan);
        btnPilihFoto = findViewById(R.id.btnPilihFoto);
        imgPreview = findViewById(R.id.imgPreview);

        String[] kategoriList = {
                "Aksesoris",
                "Fashion",
                "Buku",
                "Elektronik",
                "Lainnya"
        };

        ArrayAdapter<String> adapterKategori = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                kategoriList
        );

        adapterKategori.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerKategori.setAdapter(adapterKategori);

        btnKembali.setOnClickListener(v -> finish());
        btnPilihFoto.setOnClickListener(v -> pilihFoto());
        btnSimpan.setOnClickListener(v -> uploadBarang());
    }

    void pilihFoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();

            if (imageUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            imageUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {
                }

                imgPreview.setImageURI(imageUri);

                Toast.makeText(
                        this,
                        "Foto berhasil dipilih",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }

    void uploadBarang() {
        String nama = edtNama.getText().toString().trim();
        String harga = edtHarga.getText().toString().trim();
        String kategori = spinnerKategori.getSelectedItem().toString();
        String deskripsi = edtDeskripsi.getText().toString().trim();

        if (nama.isEmpty() || harga.isEmpty()) {
            Toast.makeText(
                    this,
                    "Nama dan harga wajib diisi",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (imageUri == null) {
            Toast.makeText(
                    this,
                    "Pilih foto barang dulu",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        MultipartBody.Part fotoPart;

        try {
            File file = createFileFromUri(imageUri);

            RequestBody requestFile = RequestBody.create(
                    MediaType.parse("image/*"),
                    file
            );

            fotoPart = MultipartBody.Part.createFormData(
                    "foto",
                    file.getName(),
                    requestFile
            );

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Gagal membaca foto: " + e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        RequestBody rbNama = RequestBody.create(MediaType.parse("text/plain"), nama);
        RequestBody rbHarga = RequestBody.create(MediaType.parse("text/plain"), harga);
        RequestBody rbKategori = RequestBody.create(MediaType.parse("text/plain"), kategori);
        RequestBody rbDeskripsi = RequestBody.create(MediaType.parse("text/plain"), deskripsi);

        String penjualNama = auth.getCurrentUser() != null
                ? auth.getCurrentUser().getEmail()
                : "User";

        RequestBody rbPenjual = RequestBody.create(
                MediaType.parse("text/plain"),
                penjualNama
        );

        btnSimpan.setEnabled(false);
        btnSimpan.setText("Mengupload...");

        apiService.uploadBarang(
                fotoPart,
                rbNama,
                rbHarga,
                rbKategori,
                rbDeskripsi,
                rbPenjual
        ).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {

                btnSimpan.setEnabled(true);
                btnSimpan.setText("Simpan Barang");

                if (response.isSuccessful()) {
                    Toast.makeText(
                            UploadBarangActivity.this,
                            "Barang berhasil diupload",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();

                } else {
                    Toast.makeText(
                            UploadBarangActivity.this,
                            "Upload gagal dari server",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                btnSimpan.setEnabled(true);
                btnSimpan.setText("Simpan Barang");

                Toast.makeText(
                        UploadBarangActivity.this,
                        "Gagal upload: " + t.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    File createFileFromUri(Uri uri) throws Exception {
        String fileName = getFileName(uri);
        File file = new File(getCacheDir(), fileName);

        InputStream inputStream = getContentResolver().openInputStream(uri);
        FileOutputStream outputStream = new FileOutputStream(file);

        byte[] buffer = new byte[4096];
        int read;

        while ((read = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, read);
        }

        outputStream.flush();
        outputStream.close();

        if (inputStream != null) {
            inputStream.close();
        }

        return file;
    }

    String getFileName(Uri uri) {
        String result = "gambar_barang.jpg";

        Cursor cursor = getContentResolver().query(uri, null, null, null, null);

        if (cursor != null) {
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);

            if (cursor.moveToFirst() && nameIndex >= 0) {
                result = cursor.getString(nameIndex);
            }

            cursor.close();
        }

        return result;
    }
}