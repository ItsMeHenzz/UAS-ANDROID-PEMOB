package com.example.projekuas.adapter;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.R;
import com.example.projekuas.model.ChatMysql;

import java.util.ArrayList;

public class ChatMysqlAdapter extends RecyclerView.Adapter<ChatMysqlAdapter.ViewHolder> {

    Context context;
    ArrayList<ChatMysql> chatList;
    String emailUser;

    public ChatMysqlAdapter(Context context, ArrayList<ChatMysql> chatList, String emailUser) {
        this.context = context;
        this.chatList = chatList;
        this.emailUser = emailUser;
    }

    @NonNull
    @Override
    public ChatMysqlAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_chat_bubble, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatMysqlAdapter.ViewHolder holder, int position) {
        ChatMysql chat = chatList.get(position);

        holder.txtPesan.setText(chat.pesan);
        holder.txtWaktu.setText(chat.waktu);

        if (chat.pengirim != null && chat.pengirim.equals(emailUser)) {
            holder.container.setGravity(Gravity.END);
            holder.bubble.setBackgroundResource(R.drawable.bg_chat_sender);
            holder.txtPesan.setTextColor(context.getResources().getColor(android.R.color.white));
            holder.txtWaktu.setTextColor(context.getResources().getColor(android.R.color.white));
        } else {
            holder.container.setGravity(Gravity.START);
            holder.bubble.setBackgroundResource(R.drawable.bg_chat_receiver);
            holder.txtPesan.setTextColor(context.getResources().getColor(android.R.color.black));
            holder.txtWaktu.setTextColor(context.getResources().getColor(android.R.color.darker_gray));
        }
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        LinearLayout container, bubble;
        TextView txtPesan, txtWaktu;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            container = itemView.findViewById(R.id.container);
            bubble = itemView.findViewById(R.id.bubble);
            txtPesan = itemView.findViewById(R.id.txtPesan);
            txtWaktu = itemView.findViewById(R.id.txtWaktu);
        }
    }
}