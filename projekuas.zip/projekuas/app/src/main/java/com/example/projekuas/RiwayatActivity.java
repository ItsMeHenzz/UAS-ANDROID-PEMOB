package com.example.projekuas;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class RiwayatActivity extends AppCompatActivity {

    ListView listRiwayat;
    Button btnKembali;

    ArrayList<String> riwayatList;
    ArrayAdapter<String> adapter;

    FirebaseFirestore db;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        listRiwayat = findViewById(R.id.listRiwayat);
        btnKembali = findViewById(R.id.btnKembali);

        riwayatList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, riwayatList);
        listRiwayat.setAdapter(adapter);

        btnKembali.setOnClickListener(v -> finish());

        loadRiwayat();
    }

    void loadRiwayat() {
        String uid = auth.getCurrentUser().getUid();

        db.collection("transaksi")
                .get()
                .addOnSuccessListener(query -> {
                    riwayatList.clear();

                    for (var doc : query) {
                        String pembeliId = doc.getString("pembeliId");
                        String penjualId = doc.getString("penjualId");
                        String namaBarang = doc.getString("namaBarang");
                        String harga = doc.getString("harga");
                        String status = doc.getString("status");

                        if (uid.equals(pembeliId) || uid.equals(penjualId)) {
                            riwayatList.add(
                                    "🛒 " + namaBarang +
                                            "\nHarga: Rp " + harga +
                                            "\nStatus: " + status
                            );
                        }
                    }

                    adapter.notifyDataSetChanged();
                });
    }
}