package com.example.projekuas;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class UlasanActivity extends AppCompatActivity {

    ImageView btnKembali;

    TextView txtNamaBarang;
    TextView txtPenjual;
    TextView btnKirimUlasan;

    EditText edtUlasan;
    RatingBar ratingBar;

    FirebaseAuth auth;
    FirebaseFirestore db;

    String barangId, namaBarang, penjual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ulasan);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnKembali = findViewById(R.id.btnKembali);

        txtNamaBarang = findViewById(R.id.txtNamaBarang);
        txtPenjual = findViewById(R.id.txtPenjual);

        edtUlasan = findViewById(R.id.edtUlasan);
        ratingBar = findViewById(R.id.ratingBar);

        btnKirimUlasan = findViewById(R.id.btnKirimUlasan);

        btnKembali.setOnClickListener(v -> finish());

        barangId = getIntent().getStringExtra("barangId");
        namaBarang = getIntent().getStringExtra("namaBarang");
        penjual = getIntent().getStringExtra("penjual");

        if (barangId == null) barangId = "";
        if (namaBarang == null) namaBarang = "Barang";
        if (penjual == null) penjual = "Penjual";

        txtNamaBarang.setText(namaBarang);
        txtPenjual.setText("Penjual • " + penjual);

        btnKirimUlasan.setOnClickListener(v -> {

            float rating = ratingBar.getRating();
            String komentar = edtUlasan.getText().toString().trim();

            if (rating == 0) {
                Toast.makeText(
                        this,
                        "Berikan rating terlebih dahulu",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (komentar.isEmpty()) {
                Toast.makeText(
                        this,
                        "Tulis ulasan terlebih dahulu",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            simpanUlasan(rating, komentar);
        });
    }

    void simpanUlasan(float rating, String komentar) {

        if (auth.getCurrentUser() == null) {
            Toast.makeText(
                    this,
                    "Silakan login dulu",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        String uid = auth.getCurrentUser().getUid();
        String email = auth.getCurrentUser().getEmail();

        HashMap<String, Object> data = new HashMap<>();

        data.put("barangId", barangId);
        data.put("namaBarang", namaBarang);
        data.put("penjual", penjual);

        data.put("userId", uid);
        data.put("userEmail", email);

        data.put("rating", rating);
        data.put("komentar", komentar);

        data.put("timestamp", System.currentTimeMillis());

        btnKirimUlasan.setEnabled(false);
        btnKirimUlasan.setText("Mengirim...");

        db.collection("ulasan")
                .add(data)
                .addOnSuccessListener(documentReference -> {

                    btnKirimUlasan.setEnabled(true);
                    btnKirimUlasan.setText("Kirim Ulasan");

                    Toast.makeText(
                            this,
                            "Ulasan berhasil dikirim",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })
                .addOnFailureListener(e -> {

                    btnKirimUlasan.setEnabled(true);
                    btnKirimUlasan.setText("Kirim Ulasan");

                    Toast.makeText(
                            this,
                            "Gagal: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }
}