package com.example.projekuas;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditBarangActivity extends AppCompatActivity {

    EditText edtNama, edtHarga, edtKategori, edtDeskripsi;
    TextView btnUpdate;
    ImageView btnKembali, imgBarang;

    ApiService apiService;

    String idBarang, fotoBarang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_barang);

        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        imgBarang = findViewById(R.id.imgBarang);

        edtNama = findViewById(R.id.edtNama);
        edtHarga = findViewById(R.id.edtHarga);
        edtKategori = findViewById(R.id.edtKategori);
        edtDeskripsi = findViewById(R.id.edtDeskripsi);

        btnUpdate = findViewById(R.id.btnUpdate);
        btnKembali = findViewById(R.id.btnKembali);

        idBarang = getIntent().getStringExtra("id");
        fotoBarang = getIntent().getStringExtra("foto");

        edtNama.setText(getIntent().getStringExtra("nama"));
        edtHarga.setText(getIntent().getStringExtra("harga"));
        edtKategori.setText(getIntent().getStringExtra("kategori"));
        edtDeskripsi.setText(getIntent().getStringExtra("deskripsi"));

        Glide.with(this)
                .load(fotoBarang)
                .placeholder(R.drawable.ic_launcher_background)
                .into(imgBarang);

        btnKembali.setOnClickListener(v -> finish());

        btnUpdate.setOnClickListener(v -> updateBarang());
    }

    void updateBarang() {
        String nama = edtNama.getText().toString().trim();
        String harga = edtHarga.getText().toString().trim();
        String kategori = edtKategori.getText().toString().trim();
        String deskripsi = edtDeskripsi.getText().toString().trim();

        if (idBarang == null || idBarang.isEmpty()) {
            Toast.makeText(this, "ID barang kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        if (nama.isEmpty() || harga.isEmpty() || kategori.isEmpty()) {
            Toast.makeText(this, "Nama, harga, dan kategori wajib diisi", Toast.LENGTH_SHORT).show();
            return;
        }

        btnUpdate.setEnabled(false);
        btnUpdate.setText("Menyimpan...");

        apiService.updateBarang(
                idBarang,
                nama,
                harga,
                kategori,
                deskripsi
        ).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {

                btnUpdate.setEnabled(true);
                btnUpdate.setText("Update Barang");

                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String hasil = response.body().string();

                        if (hasil.contains("\"status\":true") || hasil.contains("success")) {
                            Toast.makeText(EditBarangActivity.this,
                                    "Barang berhasil diupdate",
                                    Toast.LENGTH_SHORT).show();

                            finish();
                        } else {
                            Toast.makeText(EditBarangActivity.this,
                                    "Update gagal: " + hasil,
                                    Toast.LENGTH_LONG).show();
                        }

                    } catch (IOException e) {
                        Toast.makeText(EditBarangActivity.this,
                                "Gagal baca response: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(EditBarangActivity.this,
                            "Update gagal dari server",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                btnUpdate.setEnabled(true);
                btnUpdate.setText("Update Barang");

                Toast.makeText(EditBarangActivity.this,
                        "Gagal update: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}