package com.example.projekuas;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.BarangAdapter;
import com.example.projekuas.model.Barang;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class FavoriteActivity extends AppCompatActivity {

    ImageView btnKembali;
    RecyclerView recyclerFavorite;

    ArrayList<Barang> favoriteList;
    BarangAdapter adapter;

    FirebaseFirestore db;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        btnKembali = findViewById(R.id.btnKembali);
        recyclerFavorite = findViewById(R.id.recyclerFavorite);

        btnKembali.setOnClickListener(v -> finish());

        favoriteList = new ArrayList<>();
        adapter = new BarangAdapter(this, favoriteList);

        recyclerFavorite.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerFavorite.setAdapter(adapter);

        loadFavorite();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFavorite();
    }

    void loadFavorite() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Silakan login dulu", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String uid = auth.getCurrentUser().getUid();

        db.collection("favorite")
                .document(uid)
                .collection("items")
                .get()
                .addOnSuccessListener(query -> {
                    favoriteList.clear();

                    for (var doc : query) {
                        Barang barang = new Barang();

                        barang.id = doc.getString("barangId");
                        barang.nama = doc.getString("nama");
                        barang.harga = doc.getString("harga");
                        barang.kategori = doc.getString("kategori");
                        barang.deskripsi = doc.getString("deskripsi");
                        barang.fotoUrl = doc.getString("fotoUrl");
                        barang.penjualNama = doc.getString("penjualNama");
                        barang.penjualId = "";

                        if (barang.deskripsi == null || barang.deskripsi.isEmpty()) {
                            barang.deskripsi = "Barang favorite";
                        }

                        favoriteList.add(barang);
                    }

                    adapter.notifyDataSetChanged();

                    if (favoriteList.isEmpty()) {
                        Toast.makeText(this,
                                "Belum ada barang favorite",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this,
                                "Gagal memuat favorite: " + e.getMessage(),
                                Toast.LENGTH_LONG).show()
                );
    }
}