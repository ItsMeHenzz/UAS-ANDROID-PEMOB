package com.example.projekuas.model;

public class Ulasan {

    public String documentId;
    public String barangId;
    public String namaBarang;
    public String penjual;
    public String komentar;
    public float rating;

    public Ulasan() {
    }
}