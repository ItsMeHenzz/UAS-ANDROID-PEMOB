package com.example.projekuas.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.projekuas.ChatActivity;
import com.example.projekuas.R;
import com.example.projekuas.UlasanActivity;
import com.example.projekuas.model.ChatMysql;

import java.util.ArrayList;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ViewHolder> {

    Context context;
    ArrayList<ChatMysql> list;

    public ChatListAdapter(Context context, ArrayList<ChatMysql> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ChatListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_chat_list, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatListAdapter.ViewHolder holder, int position) {
        ChatMysql chat = list.get(position);

        String namaLawan = chat.penerima;

        if (namaLawan == null || namaLawan.isEmpty()) {
            namaLawan = chat.pengirim;
        }

        if (namaLawan == null || namaLawan.isEmpty()) {
            namaLawan = "User";
        }

        String namaBarang = chat.namaBarang == null ? "Barang" : chat.namaBarang;
        String fotoBarang = chat.fotoBarang == null ? "" : chat.fotoBarang;
        String pesanTerakhir = chat.pesan == null ? "" : chat.pesan;
        String waktu = chat.waktu == null ? "" : chat.waktu;

        String namaTampil = namaLawan;
        if (namaTampil.contains("@")) {
            namaTampil = namaTampil.substring(0, namaTampil.indexOf("@"));
        }

        holder.txtNamaBarang.setText(namaBarang);
        holder.txtNamaPenjual.setText("Penjual • " + namaTampil);
        holder.txtPesanTerakhir.setText(pesanTerakhir);

        if (waktu.length() >= 16) {
            holder.txtWaktu.setText(waktu.substring(11, 16));
        } else {
            holder.txtWaktu.setText(waktu);
        }

        Glide.with(context)
                .load(fotoBarang)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into(holder.imgBarangChat);

        String finalNamaLawan = namaLawan;

        holder.itemView.setOnClickListener(v -> {
            if (chat.barangId == null || chat.barangId.isEmpty()) {
                Toast.makeText(context, "Barang ID kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(context, ChatActivity.class);

            intent.putExtra("barangId", chat.barangId);
            intent.putExtra("namaBarang", namaBarang);
            intent.putExtra("fotoBarang", fotoBarang);
            intent.putExtra("penjual", finalNamaLawan);

            context.startActivity(intent);
        });

        holder.btnUlasan.setOnClickListener(v -> {
            if (chat.barangId == null || chat.barangId.isEmpty()) {
                Toast.makeText(context, "Barang ID kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(context, UlasanActivity.class);

            intent.putExtra("barangId", chat.barangId);
            intent.putExtra("namaBarang", namaBarang);
            intent.putExtra("fotoBarang", fotoBarang);
            intent.putExtra("penjual", finalNamaLawan);

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgBarangChat;
        ImageButton btnUlasan;
        TextView txtNamaBarang, txtNamaPenjual, txtPesanTerakhir, txtWaktu;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgBarangChat = itemView.findViewById(R.id.imgBarangChat);
            btnUlasan = itemView.findViewById(R.id.btnUlasan);

            txtNamaBarang = itemView.findViewById(R.id.txtNamaBarang);
            txtNamaPenjual = itemView.findViewById(R.id.txtNamaPenjual);
            txtPesanTerakhir = itemView.findViewById(R.id.txtPesanTerakhir);
            txtWaktu = itemView.findViewById(R.id.txtWaktu);
        }
    }
}