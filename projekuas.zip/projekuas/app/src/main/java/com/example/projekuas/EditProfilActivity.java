package com.example.projekuas;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class EditProfilActivity extends AppCompatActivity {

    ImageView imgProfile;
    EditText edtNama;
    Button btnPilihFoto, btnSimpan;

    FirebaseAuth auth;
    FirebaseFirestore db;

    Uri imageUri;
    String fotoLama = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        if (auth.getCurrentUser() == null) {
            finish();
            return;
        }

        imgProfile = findViewById(R.id.imgProfile);
        edtNama = findViewById(R.id.edtNama);
        btnPilihFoto = findViewById(R.id.btnPilihFoto);
        btnSimpan = findViewById(R.id.btnSimpan);

        loadProfile();

        btnPilihFoto.setOnClickListener(v -> pilihFoto());
        btnSimpan.setOnClickListener(v -> simpanProfile());
    }

    void pilihFoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();

            if (imageUri != null) {
                getContentResolver().takePersistableUriPermission(
                        imageUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );

                Glide.with(this)
                        .load(imageUri)
                        .circleCrop()
                        .placeholder(android.R.drawable.ic_menu_myplaces)
                        .into(imgProfile);
            }
        }
    }

    void loadProfile() {
        if (auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();

        db.collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        String nama = doc.getString("nama");
                        String foto = doc.getString("foto");

                        if (nama != null) {
                            edtNama.setText(nama);
                        }

                        if (foto != null && !foto.isEmpty()) {
                            fotoLama = foto;

                            Glide.with(EditProfilActivity.this)
                                    .load(foto)
                                    .circleCrop()
                                    .placeholder(android.R.drawable.ic_menu_myplaces)
                                    .into(imgProfile);
                        } else {
                            Glide.with(EditProfilActivity.this)
                                    .load(android.R.drawable.ic_menu_myplaces)
                                    .circleCrop()
                                    .into(imgProfile);
                        }
                    }
                });
    }

    void simpanProfile() {
        String nama = edtNama.getText().toString().trim();

        if (nama.isEmpty()) {
            Toast.makeText(this, "Display Name wajib diisi", Toast.LENGTH_SHORT).show();
            return;
        }

        if (auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();
        String email = auth.getCurrentUser().getEmail();

        HashMap<String, Object> user = new HashMap<>();
        user.put("nama", nama);
        user.put("email", email);

        if (imageUri != null) {
            user.put("foto", imageUri.toString());
        } else {
            user.put("foto", fotoLama);
        }

        db.collection("users")
                .document(uid)
                .set(user)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Profil berhasil diupdate", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}
