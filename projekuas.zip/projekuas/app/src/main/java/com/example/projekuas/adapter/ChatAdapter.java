package com.example.projekuas.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.R;
import com.example.projekuas.model.Chat;

import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    Context context;
    ArrayList<Chat> chatList;
    String uid;

    public ChatAdapter(Context context, ArrayList<Chat> chatList, String uid) {
        this.context = context;
        this.chatList = chatList;
        this.uid = uid;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_chat_bubble, parent, false);

        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Chat chat = chatList.get(position);

        holder.txtPesan.setText(chat.pesan);
        holder.txtWaktu.setText(chat.waktu);

        if (chat.pengirimId != null && chat.pengirimId.equals(uid)) {
            holder.container.setGravity(android.view.Gravity.END);
            holder.bubble.setBackgroundResource(R.drawable.bg_chat_sender);
            holder.txtPesan.setTextColor(context.getResources().getColor(android.R.color.white));
            holder.txtWaktu.setTextColor(context.getResources().getColor(android.R.color.white));
        } else {
            holder.container.setGravity(android.view.Gravity.START);
            holder.bubble.setBackgroundResource(R.drawable.bg_chat_receiver);
            holder.txtPesan.setTextColor(context.getResources().getColor(android.R.color.black));
            holder.txtWaktu.setTextColor(context.getResources().getColor(android.R.color.darker_gray));
        }
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public static class ChatViewHolder extends RecyclerView.ViewHolder {

        LinearLayout container, bubble;
        TextView txtPesan, txtWaktu;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);

            container = itemView.findViewById(R.id.container);
            bubble = itemView.findViewById(R.id.bubble);
            txtPesan = itemView.findViewById(R.id.txtPesan);
            txtWaktu = itemView.findViewById(R.id.txtWaktu);
        }
    }
}