package com.example.projekuas;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.BarangAdapter;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.example.projekuas.model.Barang;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class KategoriActivity extends AppCompatActivity {

    ImageView btnKembali;
    TextView txtJudulKategori;
    RecyclerView recyclerKategori;

    ArrayList<Barang> barangList;
    BarangAdapter adapter;

    ApiService apiService;

    String kategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori);

        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        btnKembali = findViewById(R.id.btnKembali);
        txtJudulKategori = findViewById(R.id.txtJudulKategori);
        recyclerKategori = findViewById(R.id.recyclerKategori);

        btnKembali.setOnClickListener(v -> finish());

        kategori = getIntent().getStringExtra("kategori");

        if (kategori == null || kategori.isEmpty() || kategori.equalsIgnoreCase("SEMUA")) {
            txtJudulKategori.setText("Semua Barang");
            kategori = "SEMUA";
        } else {
            txtJudulKategori.setText(kategori);
        }

        barangList = new ArrayList<>();
        adapter = new BarangAdapter(this, barangList);

        recyclerKategori.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerKategori.setAdapter(adapter);

        loadBarang();
    }

    void loadBarang() {
        apiService.getBarang().enqueue(new Callback<List<Barang>>() {
            @Override
            public void onResponse(Call<List<Barang>> call,
                                   Response<List<Barang>> response) {

                if (response.isSuccessful() && response.body() != null) {
                    barangList.clear();

                    for (Barang barang : response.body()) {
                        if (kategori.equalsIgnoreCase("SEMUA")) {
                            barangList.add(barang);
                        } else {
                            String kategoriBarang = barang.kategori == null ? "" : barang.kategori;

                            if (kategoriBarang.equalsIgnoreCase(kategori)) {
                                barangList.add(barang);
                            }
                        }
                    }

                    adapter.notifyDataSetChanged();

                    if (barangList.isEmpty()) {
                        Toast.makeText(KategoriActivity.this,
                                "Barang belum tersedia",
                                Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(KategoriActivity.this,
                            "Data barang kosong",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Barang>> call, Throwable t) {
                Toast.makeText(KategoriActivity.this,
                        "Gagal konek API: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}