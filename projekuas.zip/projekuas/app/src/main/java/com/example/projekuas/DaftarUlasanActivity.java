package com.example.projekuas;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.DaftarUlasanAdapter;
import com.example.projekuas.model.Ulasan;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class DaftarUlasanActivity extends AppCompatActivity {

    ImageView btnKembali;
    RecyclerView recyclerUlasan;

    ArrayList<Ulasan> list;
    DaftarUlasanAdapter adapter;

    FirebaseAuth auth;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_ulasan);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnKembali = findViewById(R.id.btnKembali);
        recyclerUlasan = findViewById(R.id.recyclerUlasan);

        btnKembali.setOnClickListener(v -> finish());

        list = new ArrayList<>();
        adapter = new DaftarUlasanAdapter(this, list);

        recyclerUlasan.setLayoutManager(new LinearLayoutManager(this));
        recyclerUlasan.setAdapter(adapter);

        loadUlasan();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUlasan();
    }

    void loadUlasan() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Silakan login dulu", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String email = auth.getCurrentUser().getEmail();

        if (email == null || email.isEmpty()) {
            Toast.makeText(this, "Email user kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        db.collection("ulasan")
                .whereEqualTo("userEmail", email)
                .get()
                .addOnSuccessListener(query -> {
                    list.clear();

                    for (var doc : query) {
                        Ulasan ulasan = new Ulasan();

                        ulasan.documentId = doc.getId();
                        ulasan.barangId = doc.getString("barangId");

                        ulasan.namaBarang = doc.getString("namaBarang");
                        ulasan.penjual = doc.getString("penjual");
                        ulasan.komentar = doc.getString("komentar");

                        Double rating = doc.getDouble("rating");
                        ulasan.rating = rating == null ? 0 : rating.floatValue();

                        if (ulasan.namaBarang == null || ulasan.namaBarang.isEmpty()) {
                            ulasan.namaBarang = "Nama Barang";
                        }

                        if (ulasan.penjual == null || ulasan.penjual.isEmpty()) {
                            ulasan.penjual = "Penjual";
                        }

                        if (ulasan.komentar == null || ulasan.komentar.isEmpty()) {
                            ulasan.komentar = "-";
                        }

                        list.add(ulasan);
                    }

                    adapter.notifyDataSetChanged();

                    if (list.isEmpty()) {
                        Toast.makeText(this,
                                "Belum ada ulasan",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this,
                                "Gagal memuat ulasan: " + e.getMessage(),
                                Toast.LENGTH_LONG).show()
                );
    }
}