package com.example.projekuas.model;

public class Barang {
    public String id, nama, harga, kategori, deskripsi, fotoUrl, penjualId, penjualNama;

    public Barang() {}

    public Barang(String id, String nama, String harga, String kategori,
                  String deskripsi, String fotoUrl, String penjualId, String penjualNama) {
        this.id = id;
        this.nama = nama;
        this.harga = harga;
        this.kategori = kategori;
        this.deskripsi = deskripsi;
        this.fotoUrl = fotoUrl;
        this.penjualId = penjualId;
        this.penjualNama = penjualNama;
    }
}