package com.example.projekuas;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class DetailBarangActivity extends AppCompatActivity {

    ImageView imgBarang;
    TextView txtNama, txtHarga, txtKategori, txtDeskripsi, txtPenjual;
    Button btnChat;
    ImageButton btnFavorite;
    TextView btnKembali;

    String idBarang, nama, harga, kategori, deskripsi, foto, penjual;

    FirebaseAuth auth;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_barang);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        imgBarang = findViewById(R.id.imgBarang);
        txtNama = findViewById(R.id.txtNama);
        txtHarga = findViewById(R.id.txtHarga);
        txtKategori = findViewById(R.id.txtKategori);
        txtDeskripsi = findViewById(R.id.txtDeskripsi);
        txtPenjual = findViewById(R.id.txtPenjual);

        btnChat = findViewById(R.id.btnChat);
        btnFavorite = findViewById(R.id.btnFavorite);
        btnKembali = findViewById(R.id.btnKembali);

        idBarang = getIntent().getStringExtra("id");
        nama = getIntent().getStringExtra("nama");
        harga = getIntent().getStringExtra("harga");
        kategori = getIntent().getStringExtra("kategori");
        deskripsi = getIntent().getStringExtra("deskripsi");
        foto = getIntent().getStringExtra("foto");
        penjual = getIntent().getStringExtra("penjual");

        if (idBarang == null || idBarang.isEmpty()) idBarang = "0";
        if (nama == null || nama.isEmpty()) nama = "Nama Barang";
        if (harga == null || harga.isEmpty()) harga = "0";
        if (kategori == null || kategori.isEmpty()) kategori = "-";
        if (deskripsi == null || deskripsi.isEmpty()) deskripsi = "-";
        if (foto == null) foto = "";
        if (penjual == null || penjual.isEmpty()) penjual = "Penjual";

        txtNama.setText(nama);
        txtHarga.setText("Rp " + harga);
        txtKategori.setText("Kategori: " + kategori);
        txtDeskripsi.setText(deskripsi);
        txtPenjual.setText("Penjual: " + penjual);

        Glide.with(this)
                .load(foto)
                .placeholder(R.drawable.ic_launcher_background)
                .into(imgBarang);

        btnKembali.setOnClickListener(v -> finish());

        btnChat.setOnClickListener(v -> {
            Intent intent = new Intent(DetailBarangActivity.this, ChatActivity.class);

            intent.putExtra("barangId", idBarang);
            intent.putExtra("namaBarang", nama);
            intent.putExtra("fotoBarang", foto);
            intent.putExtra("penjual", penjual);

            startActivity(intent);
        });

        btnFavorite.setOnClickListener(v -> simpanFavorite());
    }

    void simpanFavorite() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Silakan login dulu", Toast.LENGTH_SHORT).show();
            return;
        }

        String uid = auth.getCurrentUser().getUid();

        HashMap<String, Object> data = new HashMap<>();
        data.put("barangId", idBarang);
        data.put("nama", nama);
        data.put("harga", harga);
        data.put("kategori", kategori);
        data.put("deskripsi", deskripsi);
        data.put("fotoUrl", foto);
        data.put("penjualNama", penjual);

        db.collection("favorite")
                .document(uid)
                .collection("items")
                .document(idBarang)
                .set(data)
                .addOnSuccessListener(unused ->
                        Toast.makeText(this, "Ditambahkan ke favorite", Toast.LENGTH_SHORT).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Gagal favorite: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }
}