package com.example.projekuas;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.BarangAdapter;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.example.projekuas.model.Barang;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BarangSayaActivity extends AppCompatActivity {

    ImageView btnKembali;
    RecyclerView recyclerBarangSaya;

    ArrayList<Barang> barangList;
    BarangAdapter adapter;

    ApiService apiService;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barang_saya);

        auth = FirebaseAuth.getInstance();
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        btnKembali = findViewById(R.id.btnKembali);
        recyclerBarangSaya = findViewById(R.id.recyclerBarangSaya);

        btnKembali.setOnClickListener(v -> finish());

        barangList = new ArrayList<>();
        adapter = new BarangAdapter(this, barangList, true);

        recyclerBarangSaya.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerBarangSaya.setAdapter(adapter);

        loadBarangSaya();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBarangSaya();
    }

    void loadBarangSaya() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Silakan login dulu", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String emailUser = auth.getCurrentUser().getEmail();

        apiService.getBarang().enqueue(new Callback<List<Barang>>() {
            @Override
            public void onResponse(Call<List<Barang>> call,
                                   Response<List<Barang>> response) {

                if (response.isSuccessful() && response.body() != null) {
                    barangList.clear();

                    for (Barang barang : response.body()) {
                        if (barang.penjualNama != null
                                && barang.penjualNama.equals(emailUser)) {

                            barangList.add(barang);
                        }
                    }

                    adapter.notifyDataSetChanged();

                    if (barangList.isEmpty()) {
                        Toast.makeText(BarangSayaActivity.this,
                                "Belum ada barang yang kamu jual",
                                Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(BarangSayaActivity.this,
                            "Gagal memuat barang",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Barang>> call, Throwable t) {
                Toast.makeText(BarangSayaActivity.this,
                        "Gagal konek API: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}