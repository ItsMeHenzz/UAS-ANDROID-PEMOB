package com.example.projekuas;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekuas.adapter.ChatMysqlAdapter;
import com.example.projekuas.api.ApiService;
import com.example.projekuas.api.RetrofitClient;
import com.example.projekuas.model.ChatMysql;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatActivity extends AppCompatActivity {

    TextView txtJudulChat, txtBarang, txtAvatar, btnKembali;
    RecyclerView recyclerChat;
    EditText edtPesan;
    Button btnKirim;

    ArrayList<ChatMysql> chatList;
    ChatMysqlAdapter adapter;

    ApiService apiService;
    FirebaseAuth auth;

    String barangId, namaBarang, fotoBarang, penjual, emailUser, namaPenjual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        apiService = RetrofitClient.getRetrofit().create(ApiService.class);
        auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Silakan login dulu", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        emailUser = auth.getCurrentUser().getEmail();

        barangId = getIntent().getStringExtra("barangId");
        namaBarang = getIntent().getStringExtra("namaBarang");
        fotoBarang = getIntent().getStringExtra("fotoBarang");
        penjual = getIntent().getStringExtra("penjual");

        if (barangId == null || barangId.isEmpty()) {
            barangId = "0";
        }

        if (namaBarang == null || namaBarang.isEmpty()) {
            namaBarang = "Barang";
        }

        if (fotoBarang == null) {
            fotoBarang = "";
        }

        if (penjual == null || penjual.isEmpty()) {
            penjual = "Penjual";
        }

        namaPenjual = penjual;

        if (namaPenjual.contains("@")) {
            namaPenjual = namaPenjual.substring(0, namaPenjual.indexOf("@"));
        }

        txtJudulChat = findViewById(R.id.txtJudulChat);
        txtBarang = findViewById(R.id.txtBarang);
        txtAvatar = findViewById(R.id.txtAvatar);
        recyclerChat = findViewById(R.id.recyclerChat);
        edtPesan = findViewById(R.id.edtPesan);
        btnKirim = findViewById(R.id.btnKirim);
        btnKembali = findViewById(R.id.btnKembali);

        txtJudulChat.setText(namaBarang);
        txtBarang.setText("Penjual • " + namaPenjual);

        if (!namaPenjual.isEmpty()) {
            txtAvatar.setText(namaPenjual.substring(0, 1).toUpperCase());
        } else {
            txtAvatar.setText("P");
        }

        chatList = new ArrayList<>();
        adapter = new ChatMysqlAdapter(this, chatList, emailUser);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);

        recyclerChat.setLayoutManager(layoutManager);
        recyclerChat.setAdapter(adapter);

        btnKembali.setOnClickListener(v -> finish());

        btnKirim.setOnClickListener(v -> kirimPesan());

        loadChat();
    }

    void kirimPesan() {
        String pesan = edtPesan.getText().toString().trim();

        if (pesan.isEmpty()) {
            return;
        }

        apiService.kirimChat(
                barangId,
                namaBarang,
                fotoBarang,
                emailUser,
                penjual,
                pesan
        ).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {

                if (response.isSuccessful()) {
                    edtPesan.setText("");
                    loadChat();
                } else {
                    Toast.makeText(ChatActivity.this,
                            "Gagal kirim pesan",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(ChatActivity.this,
                        "Error : " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    void loadChat() {
        apiService.getChat(barangId).enqueue(new Callback<List<ChatMysql>>() {
            @Override
            public void onResponse(Call<List<ChatMysql>> call,
                                   Response<List<ChatMysql>> response) {

                if (response.isSuccessful() && response.body() != null) {
                    chatList.clear();
                    chatList.addAll(response.body());

                    adapter.notifyDataSetChanged();

                    if (chatList.size() > 0) {
                        recyclerChat.scrollToPosition(chatList.size() - 1);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<ChatMysql>> call, Throwable t) {
                Toast.makeText(ChatActivity.this,
                        "Gagal memuat chat: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}